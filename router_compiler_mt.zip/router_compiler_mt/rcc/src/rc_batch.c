/*
 * rc_batch.c -- parallel batch compilation using a pthread worker pool.
 *
 * Work distribution: workers pull the next job index from a mutex-protected
 * counter (dynamic load balancing).  Each worker captures its console output
 * per job in memory so results can be printed deterministically afterwards.
 */
#define _POSIX_C_SOURCE 200809L
#include "rc_batch.h"
#include "router_compiler.h"
#include "rlog.h"

#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

typedef struct {
    RcJob          *jobs;
    size_t          n;
    size_t          next;
    pthread_mutex_t lock;
} Pool;

static int take_job(Pool *p, size_t *idx)
{
    int got = 0;

    (void)pthread_mutex_lock(&p->lock);
    if (p->next < p->n) {
        *idx = p->next++;
        got = 1;
    }
    (void)pthread_mutex_unlock(&p->lock);
    return got;
}

static void run_job(RcJob *job)
{
    char *buf = NULL;
    size_t len = 0;
    char derived[4096];
    const char *out_path = job->out_path;
    FILE *mem = open_memstream(&buf, &len);

    if (mem != NULL) {
        rc_set_output(mem);
    }
    if (out_path == NULL) {
        (void)snprintf(derived, sizeof derived, "%s.rcx", job->path);
        out_path = derived;
    }

    rc_reset_config();
    if (rc_load_file(job->path) != 0) {
        job->status = RC_JOB_LOAD_ERR;
    } else if (rc_compile_to(out_path) != 0) {
        job->status = RC_JOB_COMPILE;
    } else {
        job->status = RC_JOB_OK;
    }
    RLOGI("batch", "%s -> status %d", job->path, job->status);

    rc_set_output(NULL);
    if (mem != NULL) {
        (void)fclose(mem);              /* finalises buf/len */
        job->output = buf;
    }
}

static void *worker(void *arg)
{
    Pool *p = (Pool *)arg;
    size_t idx = 0;

    while (take_job(p, &idx)) {
        run_job(&p->jobs[idx]);
    }
    rc_shutdown();                       /* free this thread's router session */
    return NULL;
}

int rc_batch_run(RcJob *jobs, size_t n, unsigned nthreads)
{
    Pool pool;
    pthread_t *tids;
    size_t i, started = 0, bad = 0;
    long cpus;

    if (jobs == NULL || n == 0U) {
        return 0;
    }
    for (i = 0; i < n; i++) {
        jobs[i].status = RC_JOB_PENDING;
        jobs[i].output = NULL;
    }
    if (nthreads == 0U) {
        cpus = sysconf(_SC_NPROCESSORS_ONLN);
        nthreads = (cpus > 0) ? (unsigned)cpus : 1U;
    }
    if ((size_t)nthreads > n) {
        nthreads = (unsigned)n;
    }

    pool.jobs = jobs;
    pool.n = n;
    pool.next = 0;
    (void)pthread_mutex_init(&pool.lock, NULL);

    tids = (pthread_t *)calloc(nthreads, sizeof *tids);
    if (tids != NULL) {
        for (i = 0; i < nthreads; i++) {
            if (pthread_create(&tids[started], NULL, worker, &pool) == 0) {
                started++;
            }
        }
    }
    if (started == 0U) {
        (void)worker(&pool);             /* could not spawn: run inline */
    }
    for (i = 0; i < started; i++) {
        (void)pthread_join(tids[i], NULL);
    }
    free(tids);
    (void)pthread_mutex_destroy(&pool.lock);

    for (i = 0; i < n; i++) {
        if (jobs[i].status != RC_JOB_OK) {
            bad++;
        }
    }
    return (int)bad;
}

void rc_batch_free(RcJob *jobs, size_t n)
{
    size_t i;

    if (jobs == NULL) {
        return;
    }
    for (i = 0; i < n; i++) {
        free(jobs[i].output);
        jobs[i].output = NULL;
    }
}
