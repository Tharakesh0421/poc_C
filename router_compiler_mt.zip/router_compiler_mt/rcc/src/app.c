#define _POSIX_C_SOURCE 200809L
#include "rc_app.h"
#include "router_compiler.h"
#include "rc_batch.h"
#include "rlog.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

static int usage(const char *prog)
{
    (void)fprintf(stderr,
        "Usage: %s                          interactive CLI\n"
        "       %s [-j N] --batch FILE...   compile FILEs in parallel on N threads\n"
        "                                   (N=0 or omitted: one thread per CPU)\n",
        prog, prog);
    return 2;
}

static int run_batch(int argc, char **argv, unsigned nthreads)
{
    RcJob *jobs;
    size_t i, n = (size_t)argc;
    int failed;

    jobs = (RcJob *)calloc(n, sizeof *jobs);
    if (jobs == NULL) {
        (void)fputs("out of memory\n", stderr);
        return 1;
    }
    for (i = 0; i < n; i++) {
        jobs[i].path = argv[i];
    }
    (void)mkdir("reports", 0755);
    (void)rlog_init("reports/router_compiler.log", RLOG_INFO);
    failed = rc_batch_run(jobs, n, nthreads);
    for (i = 0; i < n; i++) {                 /* deterministic, in-order report */
        (void)printf("##### %s : %s #####\n", jobs[i].path,
                     jobs[i].status == RC_JOB_OK ? "OK" : "FAILED");
        if (jobs[i].output != NULL) {
            (void)fputs(jobs[i].output, stdout);
        }
    }
    (void)printf("Batch finished: %zu job(s), %d failed.\n", n, failed);
    rc_batch_free(jobs, n);
    free(jobs);
    rlog_close();
    return failed != 0 ? 1 : 0;
}

int rc_app_main(int argc, char **argv)
{
    unsigned nthreads = 0;
    int i = 1, batch = 0;

    for (; i < argc; i++) {
        if (strcmp(argv[i], "-j") == 0 && i + 1 < argc) {
            char *end = NULL;
            unsigned long v = strtoul(argv[++i], &end, 10);
            if (*end != '\0' || v > 256UL) {
                return usage(argv[0]);
            }
            nthreads = (unsigned)v;
        } else if (strcmp(argv[i], "--batch") == 0) {
            batch = 1;
            i++;
            break;
        } else {
            return usage(argv[0]);
        }
    }
    if (batch) {
        return (i < argc) ? run_batch(argc - i, argv + i, nthreads) : usage(argv[0]);
    }
    return rc_run_cli();
}
