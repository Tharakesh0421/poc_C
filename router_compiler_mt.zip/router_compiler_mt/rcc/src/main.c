#include "rc_app.h"

int main(int argc, char **argv) { return rc_app_main(argc, argv); }
