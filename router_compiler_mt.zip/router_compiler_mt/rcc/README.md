# Router Config Compiler (multi-threaded, Linux)

## Build / run
    make all                       # builds build/rcc + all tests (gcc, C11, -pthread)
    ./build/rcc                    # interactive Cisco-style CLI (unchanged behaviour)
    ./build/rcc --batch a.cfg b.cfg c.cfg          # compile many configs in parallel
    ./build/rcc -j 8 --batch configs/*.cfg         # 8 worker threads (default: one per CPU)
    sudo make install              # installs to /usr/local/bin/rcc

Batch mode writes `<file>.rcx` next to every input, prints each job's console output
in input order (deterministic), and exits non-zero if any job failed.

## Verify
    make test        # 4 suites: unit, integration, cli, threads
    make coverage    # line coverage of all sources, fails below 95 %
    make sanitize    # AddressSanitizer + UBSan + LeakSanitizer
    make tsan        # ThreadSanitizer (race detection)
    make valgrind helgrind cppcheck misra gtest   # when those tools are installed
    make run-all     # everything, with reports/ output

## Threading design
* Every piece of engine state (running-config, CLI mode, error log, I/O streams) is
  `_Thread_local`: each thread owns an independent router session -> no shared data, no locks
  in the hot path, no races by construction.
* `rc_batch_run()` (src/rc_batch.c): pthread worker pool, jobs handed out through a
  mutex-protected counter (dynamic load balancing); per-job output captured in memory.
* `rlog` is protected by a mutex; each log line is written atomically.
* Call `rc_shutdown()` on any thread that used the API before it exits (frees its session).
* New API: rc_set_output/rc_set_input/rc_run_cli_io/rc_compile_to/rc_shutdown, rc_batch_run/rc_batch_free.
