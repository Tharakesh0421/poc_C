#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <sys/stat.h>
#include <stdlib.h>
#include "test_util.h"
#include "router_compiler.h"

static void feed(const char *lines) {
    char buf[512];
    const char *p = lines;
    while (*p) {
        const char *e = strchr(p, '\n');
        size_t n = e ? (size_t)(e - p) : strlen(p);
        if (n < sizeof buf) {
            memcpy(buf, p, n); buf[n] = '\n'; buf[n + 1] = 0;
            rc_execute_line(buf);
        }
        if (!e) break;
        p = e + 1;
    }
}

static void t_full_scenario(void) {
    rc_reset_config();
    feed(
        "enable\n"
        "configure terminal\n"
        "hostname R1\n"
        "interface g0/0\n"
        " ip address 10.0.0.1 255.255.255.0\n"
        " no shutdown\n"
        " exit\n"
        "interface g0/1\n"
        " ip address 20.0.0.1 255.255.255.0\n"
        " no shutdown\n"
        " exit\n"
        "ip route 30.0.0.0 255.255.255.0 20.0.0.2\n"
        "router rip\n"
        " version 2\n"
        " network 10.0.0.0\n"
        " end\n"
    );
    int warns = 0;
    int errs = rc_validate(&warns);
    ASSERT_EQ_INT(errs, 0);
}

struct GeneratedLines {
    int seen_hostname;
    int seen_ip;
};

static void check_generated_line(const char *line, void *ud)
{
    struct GeneratedLines *state = (struct GeneratedLines *)ud;
    if (strstr(line, "hostname R2") != NULL) {
        state->seen_hostname = 1;
    }
    if (strstr(line, "ip address 192.168.1.1 255.255.255.0") != NULL) {
        state->seen_ip = 1;
    }
}

static void t_config_generation(void) {
    struct GeneratedLines state = { 0, 0 };
    rc_reset_config();
    feed(
        "enable\n"
        "configure terminal\n"
        "hostname R2\n"
        "interface g0/0\n"
        " ip address 192.168.1.1 255.255.255.0\n"
        " no shutdown\n"
        " end\n"
    );
    rc_gen_config_lines(check_generated_line, &state);
    ASSERT_EQ_INT(state.seen_hostname, 1);
    ASSERT_EQ_INT(state.seen_ip, 1);
}

static void t_load_roundtrip(void) {
    rc_reset_config();
    feed(
        "enable\nconfigure terminal\n"
        "hostname RT\n"
        "interface g0/0\n ip address 1.1.1.1 255.255.255.0\n no shutdown\n exit\n"
        "end\n"
    );
    ASSERT_EQ_INT(rc_save_file("reports/test_saved.cfg"), 0);
    rc_reset_config();
    ASSERT_EQ_INT(rc_load_file("reports/test_saved.cfg"), 0);
    int warns = 0;
    int errs = rc_validate(&warns);
    ASSERT_EQ_INT(errs, 0);
}

static void t_invalid_ip(void) {
    rc_reset_config();
    feed(
        "enable\nconfigure terminal\n"
        "interface g0/0\n"
        " ip address 300.1.1.1 255.255.255.0\n"
        "end\n"
    );
    int warns = 0, errs = rc_validate(&warns);
    ASSERT_EQ_INT(errs, 0);  /* validation is on state, bad input rejected earlier */
}

int main(void) {
    mkdir("reports", 0755);
    printf("== integration tests ==\n");
    t_full_scenario();
    t_config_generation();
    t_load_roundtrip();
    t_invalid_ip();
    rc_shutdown();
    test_summary("integration");
    return 0;
}