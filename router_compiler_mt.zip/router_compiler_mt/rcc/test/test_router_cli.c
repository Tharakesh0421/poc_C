/* test_router_cli.c -- exercises every CLI command, error path, mode and file operation. */
#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <sys/stat.h>
#include "test_util.h"
#include "router_compiler.h"
#include "rc_app.h"

/* run script in config mode (fresh router) and return captured output */
static char *cfg_run(const char *script)
{
    tu_enter_config();
    return tu_run(script);
}

#define CHECK(out, needle) do { ASSERT_CONTAINS((out), (needle)); } while (0)

static void t_help_and_modes(void)
{
    char *o;
    rc_reset_config();
    o = tu_run("?\nhelp\nenable\n?\nconf?\nsh ?\nzzz ?\nshow ip ?\nconfigure terminal\n?\n"
               "interface g0/0\n?\nexit\nrouter rip\n?\nexit\nrouter ospf 1\n?\nend\n");
    CHECK(o, "Enter privileged EXEC mode");
    CHECK(o, "Enter global configuration mode");
    CHECK(o, "Unrecognized command");
    CHECK(o, "abbreviations work");
    CHECK(o, "Assign IPv4 address");
    CHECK(o, "Set RIP version");
    CHECK(o, "Set OSPF router-id");
    free(o);
}

static void t_exit_and_quit(void)
{
    rc_reset_config();
    tu_feed("exit\n");
    ASSERT_EQ_INT(rc_get_quit_flag(), 1);
    rc_set_quit_flag(0);
    ASSERT_EQ_INT(rc_get_quit_flag(), 0);
    tu_feed("enable\nconfigure terminal\ninterface g0/0\nexit\nexit\nexit\n");
    ASSERT_EQ_INT(rc_get_quit_flag(), 0);
    tu_feed("exit\n");
    ASSERT_EQ_INT(rc_get_quit_flag(), 1);
    rc_set_quit_flag(0);
    tu_feed("enable\nconfigure terminal\nrouter rip\nexit\nrouter ospf 1\nexit\nquit\n");
    ASSERT_EQ_INT(rc_get_quit_flag(), 1);
    rc_set_quit_flag(0);
    tu_feed("enable\ndisable\n");
    tu_feed("enable\nconfigure terminal\nexit\nexit\n");
    ASSERT_EQ_INT(rc_get_quit_flag(), 0);
}

static void t_enable_secret(void)
{
    char *o;
    tu_enter_config();
    tu_feed("enable secret pw\nend\ndisable\n");
    tu_input_begin("bad\r\n");
    o = tu_run("enable\nshow running-config\n");
    CHECK(o, "Access denied");
    CHECK(o, "Invalid input");
    free(o);
    tu_input_begin("pw\n");
    o = tu_run("enable\nshow running-config\n");
    CHECK(o, "enable secret pw");
    free(o);
    tu_feed("disable\n");
    tu_input_begin("");
    (void)rc_execute_line("enable\n");
    tu_input_end();
    /* a file loaded while a secret exists must not prompt */
    tu_feed("configure terminal\n");
}

static void t_hostname_secret(void)
{
    char *o = cfg_run("hostname 9bad\nhostname bad$name\nhostname RouterA\nhostname RouterA\n"
                      "no hostname\nno hostname\nenable secret s1\nenable secret s1\nenable secret s2\n"
                      "no enable secret\nno enable secret\nend\nshow running-config\n");
    CHECK(o, "Hostname must start with a letter");
    CHECK(o, "Hostname may contain only");
    CHECK(o, "hostname Router");
    free(o);
    {
        char longname[80], cmd[120];
        memset(longname, 'a', 70); longname[70] = 0;
        snprintf(cmd, sizeof cmd, "hostname %s\n", longname);
        o = cfg_run(cmd);
        CHECK(o, "at most 63");
        free(o);
        memset(longname, 'p', 70); longname[70] = 0;
        snprintf(cmd, sizeof cmd, "enable secret %s\n", longname);
        o = cfg_run(cmd);
        CHECK(o, "Password too long");
        free(o);
    }
}

static void t_interfaces(void)
{
    char *o = cfg_run("interface xyz\ninterface g0/0\nexit\ninterface g 0/0\nexit\n"
                      "interface lo1\nexit\ninterface lo2\nexit\ninterface lo3\nexit\n"
                      "no interface lo2\nno interface lo3\nno interface lo1\nno interface lo1\n"
                      "no interface g0/0\nno interface bogus\ninterface lo6\nno interface lo6\n"
                      "ip address 1.1.1.1 255.255.255.0\nend\n");
    CHECK(o, "Invalid interface. Examples");
    CHECK(o, "Cannot delete physical interface");
    CHECK(o, "does not exist");
    CHECK(o, "Invalid interface name");
    free(o);
    o = tu_run("show ip interface brief\n");
    CHECK(o, "GigabitEthernet0/0");
    ASSERT_NOT_CONTAINS(o, "Loopback");
    free(o);

    o = cfg_run("interface lo5\nip address 5.5.5.5 255.255.255.255\nexit\n"
                "interface g0/0\nexit\nip route 9.9.9.0 255.255.255.0 lo5\nno interface lo5\nend\n"
                "show running-config\n");
    ASSERT_NOT_CONTAINS(o, "ip route");
    free(o);
}

static void t_ip_address(void)
{
    char *o = cfg_run("interface g0/0\n"
                      "ip address 0.0.0.0 255.255.255.0\nip address 224.0.0.1 255.255.255.0\n"
                      "ip address 127.0.0.1 255.0.0.0\nip address abc 255.255.255.0\n"
                      "ip address 10.0.0.1 255.0.255.0\nip address 10.0.0.1 0.0.0.0\n"
                      "ip address 10.0.0.1 255.255.255.255\n"
                      "ip address 10.0.0.0 255.255.255.0\nip address 10.0.0.255 255.255.255.0\n"
                      "ip address 10.0.0.1 255.255.255.0\nip address 10.0.0.1 255.255.255.0\n"
                      "ip address 10.0.0.2 255.255.255.0\n"
                      "exit\ninterface g0/1\nip address 10.0.0.5 255.255.255.0\n"
                      "ip address 10.1.1.0 255.255.255.254\nexit\n"
                      "interface lo0\nip address 9.9.9.9 255.255.255.255\nexit\n"
                      "interface g0/0\nno ip address\nno ip address\nend\n");
    CHECK(o, "must be a unicast host address");
    CHECK(o, "1-bits must be contiguous");
    CHECK(o, "allowed only on loopbacks");
    CHECK(o, "network or broadcast address");
    CHECK(o, "overlaps with GigabitEthernet0/0");
    free(o);
}

static void t_shutdown_desc_clock(void)
{
    char *o;
    char longdesc[200], cmd[260];
    memset(longdesc, 'd', 120); longdesc[120] = 0;
    snprintf(cmd, sizeof cmd, "description %s\n", longdesc);
    o = cfg_run("interface g0/0\nshutdown\nno shutdown\nno shutdown\nshutdown\n"
                "description uplink to core\ndescription uplink to core\ndescription other\n"
                "no description\nno description\n"
                "clock rate 64000\n");
    CHECK(o, "%LINK-5-CHANGED");
    CHECK(o, "administratively down");
    CHECK(o, "Clock rate can only be set on Serial");
    free(o);
    tu_enter_config();
    tu_feed("interface g0/0\n");
    o = tu_run(cmd);
    CHECK(o, "Description too long");
    free(o);
    o = cfg_run("interface s0/0/0\nclock rate abc\nclock rate 100\nclock rate 9000000\n"
                "clock rate 64000\nclock rate 64000\nclock rate 128000\ndescription WAN\n"
                "end\nshow interfaces\nshow interfaces s0/0/0\nshow interfaces s 0/0/0\n"
                "show interfaces bogus\nshow interfaces g0/9\n"
                "configure terminal\ninterface s0/0/0\nno clock rate\nno clock rate\nend\n");
    CHECK(o, "Clock rate must be 1200-8000000");
    CHECK(o, "Clock rate 128000");
    CHECK(o, "Description: WAN");
    CHECK(o, "Internet protocol processing disabled");
    CHECK(o, "is not configured");
    free(o);
}

static const char *ROUTER_BASE =
    "interface g0/0\nip address 10.0.0.1 255.255.255.0\nno shutdown\nexit\n"
    "interface g0/1\nip address 20.0.0.1 255.255.255.0\nno shutdown\nexit\n";

static char *route_run(const char *more)
{
    char script[4096];
    snprintf(script, sizeof script, "%s%s", ROUTER_BASE, more);
    return cfg_run(script);
}

static void t_static_routes(void)
{
    char *o = route_run(
        "ip route 999.0.0.0 255.255.255.0 20.0.0.2\nip route 30.0.0.0 255.0.255.0 20.0.0.2\n"
        "ip route 30.0.0.1 255.255.255.0 20.0.0.2\nip route 30.0.0.0 255.255.255.0 0.0.0.0\n"
        "ip route 30.0.0.0 255.255.255.0 224.0.0.1\nip route 30.0.0.0 255.255.255.0 10.0.0.1\n"
        "ip route 30.0.0.0 255.255.255.0 foo\nip route 30.0.0.0 255.255.255.0 g0/5\n"
        "ip route 30.0.0.0 255.255.255.0 20.0.0.2 0\nip route 30.0.0.0 255.255.255.0 20.0.0.2 256\n"
        "ip route 30.0.0.0 255.255.255.0 20.0.0.2\nip route 30.0.0.0 255.255.255.0 20.0.0.2\n"
        "ip route 30.0.0.0 255.255.255.0 20.0.0.2 5\nip route 30.0.0.0 255.255.255.0 20.0.0.2 5\n"
        "ip route 40.0.0.0 255.255.255.0 g0/1\nip route 40.0.0.0 255.255.255.0 g0/0\n"
        "ip route 40.0.0.0 255.255.255.0 20.0.0.9\nip route 40.0.0.0 255.255.255.0 20.0.0.3\n"
        "ip route 40.0.0.0 255.255.255.128 20.0.0.3\nip route 30.0.0.0 255.255.255.0 g0/0\n"
        "ip route 50.0.0.0 255.255.255.0 99.0.0.2\n"
        "ip route 0.0.0.0 0.0.0.0 20.0.0.2\n"
        "ip route 80.0.0.0 255.255.255.0 20.0.0.2 10\nip route 80.0.0.0 255.255.255.0 g0/0\n"
        "end\nshow ip route\nshow ip route 10.0.0.77\nshow ip route 30.0.0.5\nshow ip route 40.0.0.5\n"
        "show ip route 80.0.0.1\nshow ip route 40.0.0.200\nshow ip route 1.2.3.4\nshow ip route zzz\nshow running-config\n");
    CHECK(o, "Invalid network address");
    CHECK(o, "Invalid subnet mask");
    CHECK(o, "host bits set");
    CHECK(o, "Invalid next-hop address");
    CHECK(o, "this router's own interface address");
    CHECK(o, "Next hop must be an IP address or an exit interface");
    CHECK(o, "does not exist (create it with");
    CHECK(o, "Administrative distance must be 1-255");
    CHECK(o, "Warning: next hop 99.0.0.2");
    CHECK(o, "Gateway of last resort is 20.0.0.2");
    CHECK(o, "Routing entry for 10.0.0.0/24");
    CHECK(o, "Via next hop 20.0.0.2");
    CHECK(o, "Directly connected, via GigabitEthernet0/0");
    CHECK(o, "Via next hop 20.0.0.3");
    CHECK(o, "ip route 30.0.0.0 255.255.255.0 20.0.0.2 5");
    free(o);

    o = route_run("end\nshow ip route 1.2.3.4\nshow ip route 10.0.0.1\n");
    CHECK(o, "Network not in table");
    free(o);

    o = route_run("ip route 30.0.0.0 255.255.255.0 20.0.0.2\nip route 30.0.0.0 255.255.255.0 g0/0\n"
                  "ip route 31.0.0.0 255.255.255.0 20.0.0.2\n"
                  "no ip route 999.0.0.0 255.255.255.0\nno ip route 30.0.0.0 255.0.255.0\n"
                  "no ip route 30.0.0.0 255.255.255.0 zzz\nno ip route 30.0.0.0 255.255.255.0 20.0.0.77\n"
                  "no ip route 30.0.0.0 255.255.255.0 20.0.0.2\nno ip route 30.0.0.0 255.255.255.0 g0/0\n"
                  "no ip route 31.0.0.0 255.255.255.0\nno ip route 31.0.0.0 255.255.255.0\n"
                  "end\nshow running-config\n");
    CHECK(o, "Invalid network address.");
    CHECK(o, "Invalid next hop / interface.");
    CHECK(o, "No matching route to delete.");
    ASSERT_NOT_CONTAINS(o, "ip route 3");
    free(o);
}

static void t_rip(void)
{
    char *o = cfg_run("interface g0/0\nip address 10.0.0.1 255.255.255.0\nno shutdown\nexit\n"
                      "router rip\nversion 3\nversion 2\nversion 2\nno auto-summary\nno auto-summary\n"
                      "auto-summary\nauto-summary\nnetwork 10.0.0.9\nnetwork 10.0.0.0\nnetwork 192.168.1.0\n"
                      "network 10.0.0.0 255.0.0.0\nnetwork 224.0.0.0\nnetwork abc\n"
                      "no network 10.0.0.0\nno network 10.0.0.0\nnetwork 10.0.0.0\n"
                      "router rip\nexit\n"
                      "end\nshow ip protocols\nvalidate\n"
                      "configure terminal\nno router rip\nno router rip\nend\nshow ip protocols\n");
    CHECK(o, "RIP version must be 1 or 2");
    CHECK(o, "RIP syntax: network");
    CHECK(o, "Not a valid class A/B/C network");
    CHECK(o, "Network not configured");
    CHECK(o, "automatic summarization");
    CHECK(o, "RIP network 192.168.1.0 matches no interface");
    CHECK(o, "No routing protocol is configured");
    free(o);
}

static void t_ospf(void)
{
    char *o = cfg_run("interface g0/0\nip address 10.0.0.1 255.255.255.0\nno shutdown\nexit\n"
                      "router ospf abc\nrouter ospf 1\nrouter ospf 2\nrouter ospf 1\n"
                      "router-id 0.0.0.0\nrouter-id 1.1.1.1\nrouter-id 1.1.1.1\nno router-id\nno router-id\n"
                      "router-id 2.2.2.2\n"
                      "network 10.0.0.0\nnetwork 10.0.0.0 0.0.0.255 area\nnetwork 10.0.0.x 0.0.0.255 area 0\n"
                      "network 10.0.0.0 255.0.0.255 area 0\nnetwork 10.0.0.0 0.0.0.255 zone 0\n"
                      "network 10.0.0.0 0.0.0.255 area x\nnetwork 10.0.0.0 0.0.0.255 area 0\n"
                      "network 10.0.0.0 0.0.0.255 area 0\nnetwork 10.0.0.0 0.0.0.255 area 5\n"
                      "network 172.16.0.0 0.0.255.255 area 1\n"
                      "no network 10.0.0.0\nno network 99.0.0.0 0.0.0.255 area 0\n"
                      "no network 172.16.0.0 0.0.255.255 area 1\nno network 172.16.0.0 0.0.255.255 area 1\n"
                      "exit\nrouter ospf 1\nend\nshow ip protocols\nshow ip route\n"
                      "configure terminal\nno router ospf zz\nno router ospf 7\nno router ospf 1\nno router ospf 1\n");
    CHECK(o, "OSPF process id must be 1-65535");
    CHECK(o, "already exists");
    CHECK(o, "Router-id must be a valid non-zero IPv4");
    CHECK(o, "OSPF syntax: network");
    CHECK(o, "Invalid wildcard mask");
    CHECK(o, "Expected keyword 'area'");
    CHECK(o, "Area must be a number");
    CHECK(o, "Network statement not configured");
    CHECK(o, "Router ID 2.2.2.2");
    CHECK(o, "RIP/OSPF are configured");
    CHECK(o, "is not configured");
    free(o);
}

static void t_show_misc(void)
{
    char *o;
    rc_shutdown();                       /* start with an empty error log */
    rc_reset_config();
    o = tu_run("enable\nshow ip interface brief\nshow interfaces\nshow ip route\nshow ip protocols\n"
               "show errors\nshow startup-config\nshow ip\nping 1.1.1.1\nping x\n");
    CHECK(o, "(no interfaces configured)");
    CHECK(o, "routing table is empty");
    CHECK(o, "Gateway of last resort is not set");
    CHECK(o, "No errors recorded");
    CHECK(o, "startup-config is not present");
    CHECK(o, "Incomplete command");
    CHECK(o, "UUUUU");
    free(o);

    o = route_run("ip route 30.0.0.0 255.255.255.0 20.0.0.2\nexit\nbogus\n"
                  "hostname a b\nend\nshow errors\nping 10.0.0.1\nping 30.0.0.7\nshow ip interface brief\n");
    CHECK(o, "error(s) recorded");
    CHECK(o, "Success rate is 100 percent");
    CHECK(o, "10.0.0.1");
    free(o);
    o = tu_run("ping 10.0.0.1\n");
    free(o);
    /* an interface without ip in the brief listing */
    o = cfg_run("interface g0/5\nend\nshow ip interface brief\n");
    CHECK(o, "unassigned");
    free(o);
}

static void t_validate(void)
{
    int warns = 0, errs;
    char *o;
    tu_enter_config();
    tu_feed("interface g0/0\nno shutdown\nexit\ninterface s0/0/0\nclock rate 64000\nexit\n"
            "interface g0/1\nip address 10.0.0.1 255.255.255.0\nexit\n"
            "ip route 30.0.0.0 255.255.255.0 20.0.0.2\nip route 31.0.0.0 255.255.255.0 g0/1\n"
            "router rip\nexit\nrouter rip\nnetwork 77.0.0.0\nexit\n"
            "router ospf 1\nnetwork 99.0.0.0 0.0.0.255 area 0\nend\n");
    o = tu_run("validate\n");
    CHECK(o, "hostname is still the default");
    CHECK(o, "is up but has no IP address");
    CHECK(o, "administratively down");
    CHECK(o, "has a clock rate but is down");
    CHECK(o, "next hop unreachable");
    CHECK(o, "interface down");
    CHECK(o, "RIP network 77.0.0.0 matches no interface");
    CHECK(o, "OSPF network 99.0.0.0");
    free(o);
    tu_capture_begin();
    errs = rc_validate(&warns);
    free(tu_capture_end());
    ASSERT_EQ_INT(errs, 1);              /* OSPF: no router-id and every interface is down */
    ASSERT(warns > 5);

    /* RIP with no networks, OSPF without any usable id */
    tu_enter_config();
    tu_feed("router rip\nexit\nrouter ospf 3\nend\n");
    tu_capture_begin();
    errs = rc_validate(NULL);
    o = tu_capture_end();
    ASSERT_EQ_INT(errs, 1);
    CHECK(o, "RIP is enabled but has no network statements");
    CHECK(o, "OSPF is enabled but has no network statements");
    CHECK(o, "no router-id and no up interface");
    free(o);
}

static void t_compile(void)
{
    char *o, *rcx;
    tu_chdir_tmp();
    tu_enter_config();
    tu_feed("hostname C1\nenable secret topsecret\n"
            "interface g0/0\ndescription LAN side\nip address 10.0.0.1 255.255.255.0\nno shutdown\nexit\n"
            "interface s0/0/0\ndescription WAN\nclock rate 64000\nexit\n"
            "interface g0/1\nexit\ninterface lo0\nip address 1.1.1.1 255.255.255.255\nexit\n"
            "ip route 30.0.0.0 255.255.255.0 10.0.0.2\nip route 40.0.0.0 255.255.255.0 g0/0\n"
            "router rip\nversion 2\nnetwork 10.0.0.0\nno auto-summary\nexit\n"
            "router ospf 1\nrouter-id 1.1.1.1\nnetwork 10.0.0.0 0.0.0.255 area 0\nend\n");
    o = tu_run("compile out.rcx\ncompile\n");
    CHECK(o, "Compiled");
    CHECK(o, "IF_ADMIN_DN");
    CHECK(o, "RIP_ENABLE");
    CHECK(o, "OSPF_RID");
    CHECK(o, "SET_SECRET");
    CHECK(o, "default-state interface(s) pruned");
    CHECK(o, "Compiled with");
    free(o);
    rcx = tu_read_file("out.rcx");
    CHECK(rcx, "COMMIT");
    CHECK(rcx, "; RCC executable configuration for C1");
    free(rcx);
    rcx = tu_read_file("C1.rcx");
    CHECK(rcx, "ROUTE_ADD");
    free(rcx);

    o = tu_run("compile /nonexistent_dir_xyz/o.rcx\n");
    CHECK(o, "Cannot write");
    free(o);

    tu_enter_config();
    tu_feed("router ospf 1\nend\n");
    o = tu_run("compile\n");
    CHECK(o, "Compilation aborted");
    free(o);
}

static void t_search(void)
{
    char *o = cfg_run("hostname SRV\ninterface g0/0\ndescription Core Link\nip address 10.0.0.1 255.255.255.0\n"
                      "exit\nip route 30.0.0.0 255.255.255.0 g0/0\nend\n"
                      "search g0/0\nsearch CORE\nsearch hostname\nsearch zzzzz\nsearch ip address\n");
    CHECK(o, "Interface found by hash lookup");
    CHECK(o, "[interface GigabitEthernet0/0] description Core Link");
    CHECK(o, "  hostname SRV");
    CHECK(o, "No configuration line contains");
    CHECK(o, "match(es)");
    free(o);
}

static void t_files(void)
{
    char *o, *f;
    tu_chdir_tmp();
    tu_enter_config();
    tu_feed("hostname F1\ninterface g0/0\nip address 10.0.0.1 255.255.255.0\nno shutdown\nexit\nend\n");
    o = tu_run("write\nwrite memory\nwrite foo\ncopy running-config startup-config\n"
               "show startup-config\nerase startup-config\nerase startup-config\nshow startup-config\n"
               "save mycfg.txt\nsave /nonexistent_dir_xyz/x.cfg\nwrite\n");
    CHECK(o, "Did you mean 'write memory'");
    CHECK(o, "[OK] saved to startup-config.cfg");
    CHECK(o, "hostname F1");
    CHECK(o, "[OK] startup-config erased");
    CHECK(o, "No startup-config to erase");
    CHECK(o, "configuration saved to mycfg.txt");
    CHECK(o, "Cannot open /nonexistent_dir_xyz/x.cfg for writing");
    free(o);

    o = tu_run("load mycfg.txt\nload nofile.cfg\n");
    CHECK(o, "Loaded");
    CHECK(o, "Cannot open file \"nofile.cfg\"");
    free(o);

    tu_write_file("bad.cfg", "hostname H1\n! comment\n\ninterface g0/0\n ip address 300.1.1.1 255.255.255.0\n"
                             " bogus line\n no shutdown\nexit\nip route 1.1.1.0 255.255.255.0\nend\n");
    o = tu_run("load bad.cfg\nshow errors\n");
    CHECK(o, "bad.cfg:5:");
    CHECK(o, "(3 error(s))");
    CHECK(o, "[bad.cfg:5]");
    free(o);
    ASSERT_EQ_INT(rc_load_file("bad.cfg"), -1);
    free(tu_run(""));
    tu_capture_begin();
    ASSERT_EQ_INT(rc_save_file("rt.cfg"), 0);
    ASSERT_EQ_INT(rc_load_file("rt.cfg"), 0);
    free(tu_capture_end());
    f = tu_read_file("rt.cfg");
    CHECK(f, "hostname H1");
    free(f);

    /* reload */
    tu_enter_config();
    tu_feed("hostname R9\nend\nwrite\n");
    tu_input_begin("n\n");
    free(tu_run("reload\n"));
    tu_input_begin("y\n");
    o = tu_run("reload\n");
    CHECK(o, "Restarting system");
    free(o);
    tu_input_begin("");
    free(tu_run("enable\nreload\n"));
    tu_input_end();
    tu_feed("erase startup-config\n");
    tu_input_begin("y\n");
    free(tu_run("enable\nreload\n"));
    tu_input_end();
}

static void t_parser_edges(void)
{
    char *o;
    char longline[400];
    int i, used = 0;

    tu_enter_config();
    o = tu_run("\n   \n! just a comment\nhostname X\n");
    ASSERT_EQ_INT((int)strlen(o), 0);
    free(o);

    for (i = 0; i < 18; i++) used += snprintf(longline + used, sizeof longline - (size_t)used, "w%d ", i);
    longline[used++] = '\n'; longline[used] = 0;
    o = tu_run(longline);
    CHECK(o, "Too many words on one line");
    free(o);

    o = tu_run("do show ip interface brief\ndo\ndo bogus\nexit\nexit\ndo show ip route\nbogus cmd\n"
               "enable\ns\nshow ip\nhostname\nip route 1.1.1.1\nexit extra\nshow bogus\n");
    CHECK(o, "Interface");
    CHECK(o, "Incomplete command");
    CHECK(o, "Ambiguous command");
    CHECK(o, "Invalid input detected");
    free(o);

    tu_enter_config();
    tu_feed("interface g0/0\n");
    o = tu_run("do show ip interface brief\nip address 10.0.0.1 255.255.255.0\n");
    CHECK(o, "GigabitEthernet0/0");
    CHECK(o, "");
    free(o);

    /* abbreviations */
    tu_enter_config();
    o = tu_run("int g0/0\nip addr 10.0.0.1 255.255.255.0\nno sh\nex\nend\nsh ip int br\n");
    CHECK(o, "GigabitEthernet0/0");
    free(o);
}

static void t_cli_session(void)
{
    FILE *in, *out;
    char *obuf = NULL; size_t olen = 0;

    tu_chdir_tmp();
    in = tmpfile();
    (void)fputs("enable\nconfigure terminal\nhostname CLI1\nend\nwrite memory\nexit\nexit\n", in);
    rewind(in);
    out = open_memstream(&obuf, &olen);
    ASSERT_EQ_INT(rc_run_cli_io(in, out), 0);
    (void)fclose(out); (void)fclose(in);
    CHECK(obuf, "Network Router Configuration Compiler");
    CHECK(obuf, "Bye.");
    free(obuf);

    /* second session restores the startup-config; log dir now exists */
    (void)mkdir("reports", 0755);
    obuf = NULL; olen = 0;
    in = tmpfile();
    (void)fputs("show interfaces\n", in);          /* ends on EOF without 'exit' */
    rewind(in);
    out = open_memstream(&obuf, &olen);
    ASSERT_EQ_INT(rc_run_cli_io(in, out), 0);
    (void)fclose(out); (void)fclose(in);
    CHECK(obuf, "Restoring saved startup-config");
    CHECK(obuf, "CLI1>");
    free(obuf);
}

static int redirected_run(int (*fn)(void *), void *arg, const char *stdin_text)
{
    int saved_out = dup(1), nul = open("/dev/null", O_WRONLY), rc;
    FILE *in = tmpfile();
    (void)fputs(stdin_text, in);
    rewind(in);
    (void)fflush(stdout);
    (void)dup2(nul, 1);
    {
        FILE *old = stdin;
        stdin = in;
        rc = fn(arg);
        stdin = old;
    }
    (void)fflush(stdout);
    (void)dup2(saved_out, 1);
    (void)close(saved_out); (void)close(nul); (void)fclose(in);
    return rc;
}

static int call_run_cli(void *unused) { (void)unused; return rc_run_cli(); }
static int call_app_plain(void *unused)
{
    char *argv[] = { "rcc", NULL };
    (void)unused;
    return rc_app_main(1, argv);
}

static void t_default_streams(void)
{
    tu_chdir_tmp();
    ASSERT_EQ_INT(redirected_run(call_run_cli, NULL, "exit\n"), 0);
    ASSERT_EQ_INT(redirected_run(call_app_plain, NULL, "exit\n"), 0);
    /* default (stdin/stdout) paths of the engine when no hooks are installed */
    rc_set_output(NULL);
    rc_set_input(NULL);
}

static void t_app_args(void)
{
    char *bad1[] = { "rcc", "-x", NULL };
    char *bad2[] = { "rcc", "-j", NULL };
    char *bad3[] = { "rcc", "-j", "abc", "--batch", "a", NULL };
    char *bad4[] = { "rcc", "-j", "1000", "--batch", "a", NULL };
    char *bad5[] = { "rcc", "--batch", NULL };
    char *good[] = { "rcc", "-j", "2", "--batch", "ok1.cfg", "ok2.cfg", "missing.cfg", NULL };
    char *good_ok[] = { "rcc", "--batch", "ok1.cfg", NULL };
    int saved_err = dup(2), nul = open("/dev/null", O_WRONLY), saved_out = dup(1);

    tu_chdir_tmp();
    tu_write_file("ok1.cfg", "hostname A1\ninterface g0/0\nip address 10.0.0.1 255.255.255.0\nno shutdown\nexit\nend\n");
    tu_write_file("ok2.cfg", "hostname A2\ninterface g0/0\nip address 10.0.0.1 255.255.255.0\nno shutdown\nexit\nend\n");
    (void)fflush(stdout);
    (void)dup2(nul, 2);
    (void)dup2(nul, 1);
    ASSERT_EQ_INT(rc_app_main(2, bad1), 2);
    ASSERT_EQ_INT(rc_app_main(2, bad2), 2);
    ASSERT_EQ_INT(rc_app_main(4, bad3), 2);
    ASSERT_EQ_INT(rc_app_main(4, bad4), 2);
    ASSERT_EQ_INT(rc_app_main(2, bad5), 2);
    ASSERT_EQ_INT(rc_app_main(7, good), 1);
    ASSERT_EQ_INT(rc_app_main(3, good_ok), 0);
    (void)fflush(stdout);
    (void)dup2(saved_err, 2);
    (void)dup2(saved_out, 1);
    (void)close(saved_err); (void)close(saved_out); (void)close(nul);
}

int main(void)
{
    printf("== CLI / engine tests ==\n");
    t_help_and_modes();
    t_exit_and_quit();
    t_enable_secret();
    t_hostname_secret();
    t_interfaces();
    t_ip_address();
    t_shutdown_desc_clock();
    t_static_routes();
    t_rip();
    t_ospf();
    t_show_misc();
    t_validate();
    t_compile();
    t_search();
    t_files();
    t_parser_edges();
    t_cli_session();
    t_default_streams();
    t_app_args();
    rc_shutdown();
    test_summary("cli");
    return 0;
}
