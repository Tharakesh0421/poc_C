/* test_util.h */
#ifndef TEST_UTIL_H
#define TEST_UTIL_H
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

extern int g_tests_run;
extern int g_tests_failed;

#define ASSERT(cond) do { \
    g_tests_run++; \
    if (!(cond)) { \
        g_tests_failed++; \
        fprintf(stderr, "FAIL %s:%d: %s\n", __FILE__, __LINE__, #cond); \
    } \
} while (0)

#define ASSERT_EQ_INT(a,b) ASSERT((a) == (b))
#define ASSERT_CONTAINS(hay, needle) ASSERT((hay) != NULL && strstr((hay), (needle)) != NULL)
#define ASSERT_NOT_CONTAINS(hay, needle) ASSERT((hay) != NULL && strstr((hay), (needle)) == NULL)

/* redirect stdout into a buffer, run fn, restore */
char *capture_stdout(void (*fn)(void *), void *arg);

void test_summary(const char *name);

/* --- in-process helpers built on the router's per-thread I/O hooks --- */
void  tu_capture_begin(void);          /* route this thread's router output to memory */
char *tu_capture_end(void);            /* stop capture; returns malloc'd text (caller frees) */
void  tu_feed(const char *script);     /* execute newline-separated commands */
char *tu_run(const char *script);      /* capture + feed + end */
void  tu_input_begin(const char *txt); /* next router stdin reads come from txt */
void  tu_input_end(void);
void  tu_enter_config(void);           /* reset; enable; configure terminal */
void  tu_chdir_tmp(void);              /* chdir into a fresh temp directory */
void  tu_write_file(const char *path, const char *text);
char *tu_read_file(const char *path);  /* malloc'd contents or NULL */
#endif
