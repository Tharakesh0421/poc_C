#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdint.h>
#include <string.h>
#include "test_util.h"
#include "router_compiler.h"
#include "rlog.h"
#include <stdlib.h>
#include <unistd.h>

static void t_parse_ip(void) {
    uint32_t v;
    ASSERT_EQ_INT(rc_parse_ip("192.168.1.1", &v), 1);
    ASSERT_EQ_INT(v, 0xC0A80101u);
    ASSERT_EQ_INT(rc_parse_ip("0.0.0.0", &v), 1);
    ASSERT_EQ_INT(rc_parse_ip("255.255.255.255", &v), 1);
    ASSERT_EQ_INT(v, 0xFFFFFFFFu);
    ASSERT_EQ_INT(rc_parse_ip("1.2.3", &v), 0);
    ASSERT_EQ_INT(rc_parse_ip("1.2.3.4.5", &v), 0);
    ASSERT_EQ_INT(rc_parse_ip("1.2.3.256", &v), 0);
    ASSERT_EQ_INT(rc_parse_ip("1..3.4", &v), 0);
    ASSERT_EQ_INT(rc_parse_ip("", &v), 0);
}

static void t_mask(void) {
    uint32_t m;
    ASSERT_EQ_INT(rc_parse_ip("255.255.255.0", &m), 1);
    ASSERT_EQ_INT(rc_mask_ok(m), 1);
    ASSERT_EQ_INT(rc_plen(m), 24);
    ASSERT_EQ_INT(rc_parse_ip("255.0.255.0", &m), 1);
    ASSERT_EQ_INT(rc_mask_ok(m), 0);
    ASSERT_EQ_INT(rc_parse_ip("0.0.0.0", &m), 1);
    ASSERT_EQ_INT(rc_mask_ok(m), 1);
    ASSERT_EQ_INT(rc_plen(m), 0);
}

static void t_classful(void) {
    uint32_t b, ip;
    ASSERT_EQ_INT(rc_parse_ip("10.1.2.3", &ip), 1);
    ASSERT_EQ_INT(rc_classful(ip, &b), 1);
    ASSERT_EQ_INT(b, 0x0A000000u);
    ASSERT_EQ_INT(rc_parse_ip("172.16.5.5", &ip), 1);
    ASSERT_EQ_INT(rc_classful(ip, &b), 1);
    ASSERT_EQ_INT(b, 0xAC100000u);
    ASSERT_EQ_INT(rc_parse_ip("192.168.1.1", &ip), 1);
    ASSERT_EQ_INT(rc_classful(ip, &b), 1);
    ASSERT_EQ_INT(b, 0xC0A80100u);
    ASSERT_EQ_INT(rc_parse_ip("224.0.0.1", &ip), 1);
    ASSERT_EQ_INT(rc_classful(ip, &b), 0);
}

static void t_canon_iface(void) {
    char out[40];
    ASSERT_EQ_INT(rc_canon_iface("g0/0", out, sizeof out), 1);
    ASSERT_EQ_INT(strcmp(out, "GigabitEthernet0/0"), 0);
    ASSERT_EQ_INT(rc_canon_iface("fa0/1", out, sizeof out), 1);
    ASSERT_EQ_INT(strcmp(out, "FastEthernet0/1"), 0);
    ASSERT_EQ_INT(rc_canon_iface("s0/0/0", out, sizeof out), 1);
    ASSERT_EQ_INT(strcmp(out, "Serial0/0/0"), 0);
    ASSERT_EQ_INT(rc_canon_iface("lo0", out, sizeof out), 1);
    ASSERT_EQ_INT(strcmp(out, "Loopback0"), 0);
    ASSERT_EQ_INT(rc_canon_iface("lo0/1", out, sizeof out), 0);
    ASSERT_EQ_INT(rc_canon_iface("xyz1", out, sizeof out), 0);
    ASSERT_EQ_INT(rc_canon_iface("g", out, sizeof out), 0);
}

static void t_parse_uint(void) {
    unsigned long long v;
    ASSERT_EQ_INT(rc_parse_uint("0", 0, 10, &v), 1);
    ASSERT_EQ_INT(v, 0);
    ASSERT_EQ_INT(rc_parse_uint("255", 1, 255, &v), 1);
    ASSERT_EQ_INT(v, 255);
    ASSERT_EQ_INT(rc_parse_uint("256", 1, 255, &v), 0);
    ASSERT_EQ_INT(rc_parse_uint("abc", 0, 100, &v), 0);
    ASSERT_EQ_INT(rc_parse_uint("", 0, 100, &v), 0);
}

static void t_ieq(void) {
    ASSERT_EQ_INT(rc_ieq("Hello", "hello"), 1);
    ASSERT_EQ_INT(rc_ieq("show", "SHOW"), 1);
    ASSERT_EQ_INT(rc_ieq("a", "ab"), 0);
    ASSERT_EQ_INT(rc_is_prefix_ci("gi", "GigabitEthernet"), 1);
    ASSERT_EQ_INT(rc_is_prefix_ci("xyz", "GigabitEthernet"), 0);
}


static void t_edge_cases(void) {
    uint32_t v, b;
    unsigned long long u;
    char out[40], *argv2[2];
    ASSERT_EQ_INT(rc_parse_ip("1.2.3.4x", &v), 0);
    ASSERT_EQ_INT(rc_parse_ip("1234.1.1.1", &v), 0);
    ASSERT_EQ_INT(rc_parse_ip("a.b.c.d", &v), 0);
    ASSERT_EQ_INT(rc_parse_ip("1.2.3.", &v), 0);
    ASSERT_EQ_INT(rc_parse_ip("1.2.3.4", &v), 1);
    ASSERT_EQ_INT(rc_parse_uint("12345678901", 0, 99999999999ULL, &u), 0);
    ASSERT_EQ_INT(rc_parse_uint("5", 6, 9, &u), 0);
    ASSERT_EQ_INT(rc_parse_uint("4294967295", 0, 4294967295ULL, &u), 1);
    ASSERT_EQ_INT(rc_mask_ok(0xFFFFFFFFu), 1);
    ASSERT_EQ_INT(rc_plen(0xFFFFFFFFu), 32);
    ASSERT_EQ_INT(rc_classful(0x00000001u, &b), 0);
    ASSERT_EQ_INT(rc_classful(0x7F000001u, &b), 0);
    ASSERT_EQ_INT(rc_classful(0x80010101u, &b), 1);
    ASSERT_EQ_INT(b, 0x80010000u);
    ASSERT_EQ_INT(rc_classful(0xBFFF0001u, &b), 1);
    ASSERT_EQ_INT(rc_classful(0xFF000001u, &b), 0);
    ASSERT_EQ_INT(strcmp(rc_ipstr(0x0A000001u), "10.0.0.1"), 0);
    ASSERT_EQ_INT(rc_canon_iface("g0/0/0/0", out, sizeof out), 0);
    ASSERT_EQ_INT(rc_canon_iface("g/0", out, sizeof out), 0);
    ASSERT_EQ_INT(rc_canon_iface("g0/", out, sizeof out), 0);
    ASSERT_EQ_INT(rc_canon_iface("g1234567", out, sizeof out), 0);
    ASSERT_EQ_INT(rc_canon_iface("loopback12", out, sizeof out), 1);
    ASSERT_EQ_INT(strcmp(out, "Loopback12"), 0);
    ASSERT_EQ_INT(rc_canon_iface("abcdefghijklmnopqrstuvwxyzabcdef1", out, sizeof out), 0);
    ASSERT_EQ_INT(rc_canon_iface("12", out, sizeof out), 0);
    argv2[0] = "g"; argv2[1] = "0/1";
    ASSERT_EQ_INT(rc_join_iface(2, argv2, out, sizeof out), 1);
    ASSERT_EQ_INT(strcmp(out, "GigabitEthernet0/1"), 0);
    argv2[0] = "fa0/2";
    ASSERT_EQ_INT(rc_join_iface(1, argv2, out, sizeof out), 1);
    ASSERT_EQ_INT(rc_is_prefix_ci("", "abc"), 0);
    ASSERT_EQ_INT(rc_is_prefix_ci("abcd", "abc"), 0);
    ASSERT_EQ_INT(rc_ieq("abc", "abd"), 0);
}

static void t_rlog(void) {
    char tmpl[] = "/tmp/rlog_unit_XXXXXX";
    char *d = mkdtemp(tmpl), path[128], *txt;
    ASSERT(d != NULL);
    snprintf(path, sizeof path, "%s/x.log", d);
    rlog_close();                                   /* close without init is safe */
    RLOGD("unit", "before init %d", 1);             /* goes to stderr, unfiltered */
    ASSERT_EQ_INT(rlog_init("/nonexistent_dir_xyz/x.log", RLOG_INFO), -1);
    ASSERT_EQ_INT(rlog_init(path, RLOG_INFO), 0);
    ASSERT_EQ_INT(rlog_init(path, RLOG_INFO), 0);   /* re-init must not leak */
    RLOGD("unit", "filtered out");
    RLOGI("unit", "info %d", 1);
    RLOGW("unit", "warn");
    RLOGE(NULL, "error without module");
    rlog_log((RlogLevel)99, "unit", "unknown level");
    rlog_log(RLOG_INFO, "unit", NULL);              /* NULL format ignored */
    rlog_close();
    txt = tu_read_file(path);
    ASSERT_CONTAINS(txt, "[INFO ] [unit] info 1");
    ASSERT_CONTAINS(txt, "[WARN ] [unit] warn");
    ASSERT_CONTAINS(txt, "[ERROR] [-] error without module");
    ASSERT_CONTAINS(txt, "[UNKNOWN] [unit] unknown level");
    ASSERT_NOT_CONTAINS(txt, "filtered out");
    free(txt);
    ASSERT_EQ_INT(rlog_init(NULL, RLOG_ERROR), 0);  /* stderr only */
    RLOGW("unit", "suppressed by level");
    rlog_close();
}

int main(void) {
    printf("== unit tests ==\n");
    t_parse_ip();
    t_mask();
    t_classful();
    t_canon_iface();
    t_parse_uint();
    t_ieq();
    t_edge_cases();
    t_rlog();
    rc_shutdown();
    test_summary("unit");
    return 0;
}