/* test_router_threads.c -- multi-threading tests: batch worker pool, session isolation, logging. */
#define _POSIX_C_SOURCE 200809L
#include <pthread.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>
#include "test_util.h"
#include "router_compiler.h"
#include "rc_batch.h"
#include "rlog.h"

#define NVALID 10
#define NJOBS  (NVALID + 3)

static void make_configs(void)
{
    char name[64], text[512];
    int i;
    for (i = 0; i < NVALID; i++) {
        snprintf(name, sizeof name, "valid%d.cfg", i);
        snprintf(text, sizeof text,
                 "hostname HOST%d\ninterface g0/0\n ip address 10.%d.0.1 255.255.255.0\n no shutdown\n exit\n"
                 "interface g0/1\n ip address 20.%d.0.1 255.255.255.0\n no shutdown\n exit\n"
                 "ip route 30.%d.0.0 255.255.255.0 20.%d.0.2\nrouter rip\n version 2\n network 10.0.0.0\nend\n",
                 i, i + 1, i + 1, i + 1, i + 1);
        tu_write_file(name, text);
    }
    tu_write_file("badsyntax.cfg", "hostname X\nthis is not a command\nend\n");
    tu_write_file("badsemantic.cfg", "hostname Y\nrouter ospf 1\nend\n");
}

static void setup_jobs(RcJob *jobs, char paths[][64], char outs[][96], const char *outdir)
{
    int i;
    for (i = 0; i < NJOBS; i++) {
        if (i < NVALID)          snprintf(paths[i], 64, "valid%d.cfg", i);
        else if (i == NVALID)    snprintf(paths[i], 64, "badsyntax.cfg");
        else if (i == NVALID + 1) snprintf(paths[i], 64, "badsemantic.cfg");
        else                     snprintf(paths[i], 64, "does_not_exist.cfg");
        snprintf(outs[i], 96, "%s/job%d.rcx", outdir, i);
        jobs[i].path = paths[i];
        jobs[i].out_path = outs[i];
    }
}

static void t_batch(void)
{
    RcJob a[NJOBS], b[NJOBS], c[NJOBS];
    char pa[NJOBS][64], oa[NJOBS][96], pb[NJOBS][64], ob[NJOBS][96], pc[NJOBS][64], oc[NJOBS][96];
    int i, bad;

    tu_chdir_tmp();
    (void)mkdir("A", 0755); (void)mkdir("B", 0755); (void)mkdir("C", 0755);
    make_configs();
    setup_jobs(a, pa, oa, "A");
    setup_jobs(b, pb, ob, "B");
    setup_jobs(c, pc, oc, "C");

    bad = rc_batch_run(a, NJOBS, 1);       /* sequential reference */
    ASSERT_EQ_INT(bad, 3);
    ASSERT_EQ_INT(rc_batch_run(b, NJOBS, 8), 3);   /* parallel */
    ASSERT_EQ_INT(rc_batch_run(c, NJOBS, 0), 3);   /* auto = one per CPU */

    for (i = 0; i < NJOBS; i++) {
        char *ra, *rb, *rc2;
        ASSERT_EQ_INT(a[i].status, b[i].status);
        ASSERT_EQ_INT(a[i].status, c[i].status);
        ASSERT(a[i].output != NULL && b[i].output != NULL);
        if (i < NVALID) {
            ASSERT_EQ_INT(a[i].status, RC_JOB_OK);
            ra = tu_read_file(oa[i]); rb = tu_read_file(ob[i]); rc2 = tu_read_file(oc[i]);
            ASSERT(ra != NULL && rb != NULL && rc2 != NULL);
            ASSERT_CONTAINS(ra, "COMMIT");
            ASSERT(rb != NULL && ra != NULL && strcmp(ra, rb) == 0);   /* identical output regardless of threads */
            ASSERT(rc2 != NULL && ra != NULL && strcmp(ra, rc2) == 0);
            { char host[32]; snprintf(host, sizeof host, "SET_HOST    HOST%d", i); ASSERT_CONTAINS(ra, host); }
            free(ra); free(rb); free(rc2);
        }
    }
    ASSERT_EQ_INT(a[NVALID].status, RC_JOB_LOAD_ERR);
    ASSERT_EQ_INT(a[NVALID + 1].status, RC_JOB_COMPILE);
    ASSERT_EQ_INT(a[NVALID + 2].status, RC_JOB_LOAD_ERR);
    ASSERT_CONTAINS(a[NVALID + 1].output, "Compilation aborted");
    ASSERT_CONTAINS(a[NVALID + 2].output, "Cannot open file");
    rc_batch_free(a, NJOBS); rc_batch_free(b, NJOBS); rc_batch_free(c, NJOBS);

    /* default output path "<path>.rcx" and more threads than jobs */
    {
        RcJob one;
        char *r;
        one.path = "valid0.cfg"; one.out_path = NULL;
        ASSERT_EQ_INT(rc_batch_run(&one, 1, 64), 0);
        r = tu_read_file("valid0.cfg.rcx");
        ASSERT_CONTAINS(r, "SET_HOST");
        free(r);
        rc_batch_free(&one, 1);
    }
    ASSERT_EQ_INT(rc_batch_run(NULL, 5, 2), 0);
    ASSERT_EQ_INT(rc_batch_run(a, 0, 2), 0);
    rc_batch_free(NULL, 0);
}

/* ---------- session isolation: each thread has its own running-config ---------- */
#define ISO_THREADS 8
#define ISO_ROUNDS  100

typedef struct { int id; int ok; } IsoArg;

struct SeenState { int host; int ip; };
static void iso_cb(const char *line, void *ud)
{
    struct SeenState *s = (struct SeenState *)ud;
    (void)line; (void)s;
}

static void *iso_worker(void *p)
{
    IsoArg *a = (IsoArg *)p;
    int r;
    a->ok = 1;
    for (r = 0; r < ISO_ROUNDS; r++) {
        char cmd[128], want_host[64], want_ip[64];
        FILE *m; char *buf = NULL; size_t len = 0;
        struct SeenState st = { 0, 0 };
        m = open_memstream(&buf, &len);
        rc_set_output(m);
        rc_reset_config();
        (void)rc_execute_line("enable\n");
        (void)rc_execute_line("configure terminal\n");
        snprintf(cmd, sizeof cmd, "hostname T%d\n", a->id);
        (void)rc_execute_line(cmd);
        (void)rc_execute_line("interface g0/0\n");
        snprintf(cmd, sizeof cmd, "ip address 10.%d.%d.1 255.255.255.0\n", a->id + 1, r % 200);
        (void)rc_execute_line(cmd);
        (void)rc_execute_line("end\n");
        (void)rc_execute_line("show running-config\n");
        rc_gen_config_lines(iso_cb, &st);
        rc_set_output(NULL);
        (void)fclose(m);
        snprintf(want_host, sizeof want_host, "hostname T%d\n", a->id);
        snprintf(want_ip, sizeof want_ip, "ip address 10.%d.%d.1 255.255.255.0", a->id + 1, r % 200);
        if (buf == NULL || strstr(buf, want_host) == NULL || strstr(buf, want_ip) == NULL) a->ok = 0;
        /* no other thread's hostname may leak in */
        {
            int t;
            for (t = 0; t < ISO_THREADS; t++) {
                char other[64];
                snprintf(other, sizeof other, "hostname T%d\n", t);
                if (t != a->id && buf != NULL && strstr(buf, other) != NULL) a->ok = 0;
            }
        }
        free(buf);
    }
    rc_shutdown();
    return NULL;
}

static void t_isolation(void)
{
    pthread_t th[ISO_THREADS];
    IsoArg args[ISO_THREADS];
    int i;
    for (i = 0; i < ISO_THREADS; i++) {
        args[i].id = i; args[i].ok = 0;
        ASSERT_EQ_INT(pthread_create(&th[i], NULL, iso_worker, &args[i]), 0);
    }
    for (i = 0; i < ISO_THREADS; i++) {
        (void)pthread_join(th[i], NULL);
        ASSERT_EQ_INT(args[i].ok, 1);
    }
}

/* ---------- concurrent logging: lines must never interleave or get lost ---------- */
#define LOG_THREADS 8
#define LOG_LINES   250

static void *log_worker(void *p)
{
    int id = *(int *)p, i;
    for (i = 0; i < LOG_LINES; i++) {
        RLOGI("mt", "thread %d item %d payload-end", id, i);
    }
    return NULL;
}

static void t_concurrent_logging(void)
{
    pthread_t th[LOG_THREADS];
    int ids[LOG_THREADS], i, count = 0, good = 0;
    char *txt, *line;
    char *save = NULL;

    tu_chdir_tmp();
    ASSERT_EQ_INT(rlog_init("mt.log", RLOG_DEBUG), 0);
    for (i = 0; i < LOG_THREADS; i++) {
        ids[i] = i;
        ASSERT_EQ_INT(pthread_create(&th[i], NULL, log_worker, &ids[i]), 0);
    }
    for (i = 0; i < LOG_THREADS; i++) (void)pthread_join(th[i], NULL);
    rlog_close();
    txt = tu_read_file("mt.log");
    ASSERT(txt != NULL);
    for (line = strtok_r(txt, "\n", &save); line != NULL; line = strtok_r(NULL, "\n", &save)) {
        size_t n = strlen(line);
        count++;
        if (n > 30 && line[4] == '-' && strstr(line, " [INFO ] [mt] thread ") != NULL &&
            n >= 12 && strcmp(line + n - 11, "payload-end") == 0) good++;
    }
    ASSERT_EQ_INT(count, LOG_THREADS * LOG_LINES);
    ASSERT_EQ_INT(good, LOG_THREADS * LOG_LINES);
    free(txt);
}

int main(void)
{
    printf("== multi-threading tests ==\n");
    t_batch();
    t_isolation();
    t_concurrent_logging();
    rc_shutdown();
    test_summary("threads");
    return 0;
}
