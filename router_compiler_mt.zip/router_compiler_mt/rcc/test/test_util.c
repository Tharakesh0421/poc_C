/* test_util.c */
#define _POSIX_C_SOURCE 200809L
#include "test_util.h"
#include "router_compiler.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/wait.h>

int g_tests_run = 0;
int g_tests_failed = 0;

char *capture_stdout(void (*fn)(void *), void *arg)
{
    int   pipefd[2];
    pid_t pid;
    char *buf = NULL;
    size_t cap = 0, len = 0;
    ssize_t n;
    int   status;

    if (pipe(pipefd) != 0) return NULL;
    pid = fork();
    if (pid == 0) {
        close(pipefd[0]);
        dup2(pipefd[1], STDOUT_FILENO);
        close(pipefd[1]);
        fn(arg);
        fflush(stdout);
        _exit(0);
    }
    close(pipefd[1]);
    {
        char tmp[4096];
        while ((n = read(pipefd[0], tmp, sizeof tmp)) > 0) {
            if (len + (size_t)n + 1 > cap) {
                cap = (len + (size_t)n + 1) * 2;
                char *grown = realloc(buf, cap);
                if (grown == NULL) {
                    free(buf);
                    close(pipefd[0]);
                    (void)waitpid(pid, &status, 0);
                    return NULL;
                }
                buf = grown;
            }
            memcpy(buf + len, tmp, (size_t)n);
            len += (size_t)n;
        }
    }
    close(pipefd[0]);
    waitpid(pid, &status, 0);
    if (!buf) buf = malloc(1);
    if (buf == NULL) return NULL;
    buf[len] = 0;
    return buf;
}

void test_summary(const char *name)
{
    fprintf(stderr, "\n[%s] %d assertion(s) run, %d failure(s)\n",
            name, g_tests_run, g_tests_failed);
    if (g_tests_failed) exit(EXIT_FAILURE);
}
/* ------------------------------------------------------------------ */
static FILE  *g_cap;
static char  *g_cap_buf;
static size_t g_cap_len;
static FILE  *g_in;

void tu_capture_begin(void)
{
    g_cap_buf = NULL; g_cap_len = 0;
    g_cap = open_memstream(&g_cap_buf, &g_cap_len);
    rc_set_output(g_cap);
}

char *tu_capture_end(void)
{
    char *r;
    rc_set_output(NULL);
    (void)fclose(g_cap);
    g_cap = NULL;
    r = g_cap_buf;
    g_cap_buf = NULL;
    return r;
}

void tu_feed(const char *lines)
{
    char buf[512];
    const char *p = lines;
    while (*p) {
        const char *e = strchr(p, '\n');
        size_t n = e ? (size_t)(e - p) : strlen(p);
        if (n < sizeof buf - 2) {
            memcpy(buf, p, n); buf[n] = '\n'; buf[n + 1] = 0;
            (void)rc_execute_line(buf);
        }
        if (!e) break;
        p = e + 1;
    }
}

char *tu_run(const char *script)
{
    tu_capture_begin();
    tu_feed(script);
    return tu_capture_end();
}

void tu_input_begin(const char *txt)
{
    tu_input_end();
    g_in = tmpfile();
    if (g_in != NULL) {
        (void)fputs(txt, g_in);
        rewind(g_in);
    }
    rc_set_input(g_in);
}

void tu_input_end(void)
{
    rc_set_input(NULL);
    if (g_in != NULL) { (void)fclose(g_in); g_in = NULL; }
}

void tu_enter_config(void)
{
    rc_reset_config();
    tu_feed("enable\nconfigure terminal\n");
}

void tu_chdir_tmp(void)
{
    char tmpl[] = "/tmp/rcc_test_XXXXXX";
    char *d = mkdtemp(tmpl);
    if (d == NULL || chdir(d) != 0) {
        fprintf(stderr, "cannot create/enter temp dir\n");
        exit(EXIT_FAILURE);
    }
}

void tu_write_file(const char *path, const char *text)
{
    FILE *f = fopen(path, "w");
    if (f != NULL) { (void)fputs(text, f); (void)fclose(f); }
}

char *tu_read_file(const char *path)
{
    FILE *f = fopen(path, "r");
    char *buf; long n;
    if (f == NULL) return NULL;
    (void)fseek(f, 0, SEEK_END); n = ftell(f); (void)fseek(f, 0, SEEK_SET);
    buf = malloc((size_t)n + 1);
    if (buf != NULL) { size_t got = fread(buf, 1, (size_t)n, f); buf[got] = 0; }
    (void)fclose(f);
    return buf;
}
