#ifndef RC_APP_H
#define RC_APP_H

#ifdef __cplusplus
extern "C" {
#endif

/* Command-line front end (interactive CLI or "--batch" parallel compile).
 * Returns the process exit status.                                       */
int rc_app_main(int argc, char **argv);

#ifdef __cplusplus
}
#endif
#endif
