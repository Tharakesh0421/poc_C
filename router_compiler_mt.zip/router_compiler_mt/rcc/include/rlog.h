#ifndef RLOG_H
#define RLOG_H

#include <stddef.h>

typedef enum { RLOG_DEBUG, RLOG_INFO, RLOG_WARN, RLOG_ERROR } RlogLevel;

/* Initialise logging to the given file (NULL => stderr only). */
int  rlog_init(const char *path, RlogLevel min_level);

/* Close log file. */
void rlog_close(void);

/* Emit one log line: "YYYY-MM-DD HH:MM:SS.mmm [LEVEL] [module] msg". */
void rlog_log(RlogLevel lvl, const char *module, const char *fmt, ...);

#define RLOGD(mod, ...) rlog_log(RLOG_DEBUG, (mod), __VA_ARGS__)
#define RLOGI(mod, ...) rlog_log(RLOG_INFO,  (mod), __VA_ARGS__)
#define RLOGW(mod, ...) rlog_log(RLOG_WARN,  (mod), __VA_ARGS__)
#define RLOGE(mod, ...) rlog_log(RLOG_ERROR, (mod), __VA_ARGS__)

#endif