#ifndef RC_BATCH_H
#define RC_BATCH_H

#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* Result codes stored in RcJob.status */
enum {
    RC_JOB_OK       = 0,   /* loaded, validated and compiled          */
    RC_JOB_LOAD_ERR = 1,   /* file missing or contained bad commands  */
    RC_JOB_COMPILE  = 2,   /* validation errors / cannot write output */
    RC_JOB_PENDING  = -1   /* not processed yet                       */
};

typedef struct {
    const char *path;      /* IN : configuration file to compile                 */
    const char *out_path;  /* IN : .rcx output; NULL => "<path>.rcx"             */
    int         status;    /* OUT: RC_JOB_*                                      */
    char       *output;    /* OUT: captured console text (malloc'd, may be NULL) */
} RcJob;

/*
 * Compile `n` configuration files on `nthreads` worker threads
 * (0 => number of online CPUs, always capped at n).  Each worker owns a
 * private router session, so jobs run truly in parallel.
 * Returns the number of jobs that did not finish with RC_JOB_OK.
 */
int  rc_batch_run(RcJob *jobs, size_t n, unsigned nthreads);

/* Release the captured output of every job. */
void rc_batch_free(RcJob *jobs, size_t n);

#ifdef __cplusplus
}
#endif
#endif
